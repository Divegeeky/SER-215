package banking.gui.servlet;

import java.io.*;
import java.text.MessageFormat;
import javax.servlet.*;
import javax.servlet.http.*;

import banking.entity.core.*;
import banking.server.BankServer;

public class AccountEditServlet extends HttpServlet {

    int callCount = 0;

/*
    BankServer server;

    public void init(ServletConfig config) {
        server = (BankServer) new banking.server.serial.SerialServerProxy(); 
    }
*/

    public void doGet (HttpServletRequest req, HttpServletResponse res)
                      throws ServletException, IOException {
        try {

        String accountName = req.getParameter("AccountName");
        if (accountName == null) {
        }

        BankServer server = new BankServer(); 
        Account acc = server.getAccount(accountName);

        displayGet(res.getWriter(), acc);

        }
        catch (Exception e) {e.printStackTrace();}
    }


    protected static MessageFormat selectBox = new MessageFormat(
        "<SELECT NAME=\"{0}\">" +
            "<OPTION VALUE=\"Closed\" {1}>Closed" +
            "<OPTION VALUE=\"Open\" {2} />Open" +
        "</SELECT>");

    protected void displayGet(PrintWriter out, Account acc)
            throws Exception {

        out.println("<html><body>");
        if (acc == null) {
            out.println("No such account");
        } else {
            out.println("<H2>Edit account " + acc.getName() + "</H2>");
            out.println("<form method=\"POST\">");

            out.println("<Input type=\"HIDDEN\" name=\"AccountName\" value=\""+ acc.getName() + "\">");
            out.println("<Input type=\"TEXT\" size=\"20\" name=\"NewAccountName\" value=\""+ acc.getName() + "\">");
            out.println("<Input type=\"TEXT\" size=\"20\" name=\"AccountBalance\" value=\""+ acc.getBalance() + "\">");

            out.println("<INPUT TYPE=SUBMIT NAME=\"SUBMIT\" VALUE=\"SUBMIT\">");
        }
        out.println("</form></body></html>");
    }


    public void doPost (HttpServletRequest req, HttpServletResponse res)
                      throws ServletException, IOException {

        ServletOutputStream out = res.getOutputStream();
        String accountName  = req.getParameter("AccountName");
        String newAccountName  = req.getParameter("NewAccountName");
        String accountBalanceS  = req.getParameter("AccountBalance");

        try {


        BankServer server = new BankServer(); 
        Account acc = server.getAccount(accountName);

        int balance = Integer.parseInt(accountBalanceS);
        acc.setBalance(balance);
        acc.setName(newAccountName);
        server.updateAccount(acc);

        //** Display results (should be a JSP too)
        out.println("<html>");
        out.println("Name is now: " + newAccountName);
        out.println("<br>Balance is now: " + accountBalanceS);
        out.println("<br><a href=\"/AccountApp\">Click here to continue</a>");
        out.println("</html>");

        }
        catch (Exception e) {
            out.println("An error occurred: " + e);
            e.printStackTrace();
        }

    }
}
