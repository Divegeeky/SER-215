package banking.db;

import java.util.List;

import banking.entity.core.Customer;

public interface CustomerAccessor {
    public Customer create(String name, String phone);
    public Customer read(int id);
    public Customer read(String name);
    public List<Customer> readAll();
    public void update(Customer obj);
    public void delete(Customer obj);
}
