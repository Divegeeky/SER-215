package banking.db;

public interface EntityAccessorFactory {

	public CheckingAccessor getCheckingAccessor();	
	public SavingsAccessor getSavingsAccessor();
	public CustomerAccessor getCustomerAccessor();

}