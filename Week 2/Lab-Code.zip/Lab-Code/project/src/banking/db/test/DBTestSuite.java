package banking.db.test;

import java.io.FileInputStream;
import java.util.Properties;

import junit.framework.Test;
import junit.framework.TestSuite;

public class DBTestSuite {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for banking.db.test");
		
		// All test cases use this property to determine which abstract
		// factory to choose.
		System.setProperty("banking.db.test.factoryname", "Stub");
		
        // Add our properties to the system properties.
		// These are used by the banking.db.rdb classes for db properties
		// including DB url, driver, and connection pool size
		String propertyFileName = "lib/db.properties";
        Properties sysProps = System.getProperties();
        try {
            sysProps.load(new FileInputStream(propertyFileName));
        } catch (Exception e) {
        	System.out.println("Error: could not load property file :" + propertyFileName);
        	e.printStackTrace();
        }


		//$JUnit-BEGIN$
		suite.addTestSuite(TestChecking.class);
		suite.addTestSuite(TestSavings.class);
		suite.addTestSuite(TestCustomer.class);
		suite.addTestSuite(TestDBDump.class);
		//$JUnit-END$
		return suite;
	}

}
