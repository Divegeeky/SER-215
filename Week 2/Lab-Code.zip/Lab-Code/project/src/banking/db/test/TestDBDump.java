package banking.db.test;


public class TestDBDump extends BaseTest {
	
	public void testCustomerDump() {
		System.out.println("All customers :" + customerDB.readAll());
		assertEquals(1, 1);
	}

	public void testSavingsDump() {
		System.out.println("All savings   :" + savingsDB.readAll());
	}
	
	public void testCheckingDump() {
		System.out.println("All checking  :" + checkingDB.readAll());
	}
}
