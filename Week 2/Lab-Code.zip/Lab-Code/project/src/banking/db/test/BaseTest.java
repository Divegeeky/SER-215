package banking.db.test;

import junit.framework.TestCase;
import banking.db.CheckingAccessor;
import banking.db.CustomerAccessor;
import banking.db.EntityAccessorFactory;
import banking.db.EntityAccessorFactoryManager;
import banking.db.SavingsAccessor;

public class BaseTest extends TestCase {

	SavingsAccessor savingsDB;
	CheckingAccessor checkingDB;
	CustomerAccessor customerDB;

	@Override
	protected void setUp() throws Exception {
		String factoryName = System.getProperty("banking.db.test.factoryname");
		if (factoryName == null)
			factoryName = "Stub";
		
		EntityAccessorFactoryManager mgr = EntityAccessorFactoryManager.getMe();
		EntityAccessorFactory factory = mgr.getPrimitiveAccessorFactory(factoryName);
		savingsDB = factory.getSavingsAccessor();
		checkingDB = factory.getCheckingAccessor();
		customerDB = factory.getCustomerAccessor();
		
//		System.out.println(getClass() + " using factory: " + factoryName);
	}

}
