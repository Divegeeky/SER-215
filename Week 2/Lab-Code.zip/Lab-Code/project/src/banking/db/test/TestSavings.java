package banking.db.test;

import java.util.List;

import banking.entity.core.Customer;
import banking.entity.core.Savings;

public class TestSavings extends BaseTest {

	public void testRead() {
		Savings s = (Savings) savingsDB.read(1);
		assertTrue(s != null);
		assertTrue(s.getId() == 1);
	}
	
	public void testCreateDelete() {
		List<Savings> allSavingsStart = savingsDB.readAll();

		Customer cust = (Customer) customerDB.read(2);
		savingsDB.create(cust.getId(), "Test Savings", 1000);
		savingsDB.create(cust.getId(), "Test Savings2", 2000);
		
		// Should have 2 more
		assertEquals(allSavingsStart.size() + 2, savingsDB.readAll().size());
		
		Savings s1 = (Savings) savingsDB.read("Test Savings");
		assertEquals(1000, s1.getBalance());
		assertEquals(cust.getId(), s1.getCustomerId());
		assertEquals("Test Savings", s1.getName());
		
		Savings s2 = (Savings) savingsDB.read("Test Savings2");
		savingsDB.delete(s1);
		savingsDB.delete(s2);
		
		// Two more should be gone
		assertEquals(allSavingsStart.size(), savingsDB.readAll().size());		
	}
	
	public void testWithdraw() {
		Savings s = (Savings) savingsDB.read(1);
		int amount = s.getBalance();
		
		s.withdraw(200);
		// Savings accounts are charged 10 dollars for each deposit
		assertEquals(amount - 200, s.getBalance());		
	}

	public void testDeposit() {
		Savings s = (Savings) savingsDB.read(1);
		int amount = s.getBalance();
		s.deposit(200);
		// Savings accounts are charged 10 dollars for each deposit
		assertEquals(amount + 200 - 10, s.getBalance());
	}
}
