package banking.db.test;

import java.util.List;

import banking.entity.core.Checking;
import banking.entity.core.Customer;

public class TestChecking extends BaseTest {

	public void testRead() {
		Checking c = (Checking) checkingDB.read(2);
		assertTrue(c != null);
		assertTrue(c.getId() == 2);
	}
	
	public void testCreateDelete() {
		List<Checking> allCheckingStart = checkingDB.readAll();

		Customer cust = (Customer) customerDB.read(2);
		checkingDB.create(cust.getId(), "Test Checking", 1000);
		checkingDB.create(cust.getId(), "Test Checking2", 2000);
		
		// Should have 2 more
		assertEquals(allCheckingStart.size() + 2, checkingDB.readAll().size());
		
		Checking s1 = (Checking) checkingDB.read("Test Checking");
		assertEquals(1000, s1.getBalance());
		assertEquals(cust.getId(), s1.getCustomerId());
		assertEquals("Test Checking", s1.getName());
		
		Checking s2 = (Checking) checkingDB.read("Test Checking2");
		checkingDB.delete(s1);
		checkingDB.delete(s2);
		
		// Two more should be gone
		assertEquals(allCheckingStart.size(), checkingDB.readAll().size());		
	}
	
	public void testWithdraw() {
		Checking c = (Checking) checkingDB.read(2);
		int amount = c.getBalance();
		
		c.withdraw(200);
		// Checking accounts are charged 10 dollars for each deposit
		assertEquals(amount - 200, c.getBalance());		
	}

	public void testDeposit() {
		Checking c = (Checking) checkingDB.read(2);
		int amount = c.getBalance();
		c.deposit(200);
		// Checking accounts are charged 10 dollars for each deposit
		assertEquals(amount + 200, c.getBalance());
	}
	
}
