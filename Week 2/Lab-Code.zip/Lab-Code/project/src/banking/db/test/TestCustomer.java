package banking.db.test;

import java.util.List;

import banking.entity.core.Customer;

public class TestCustomer extends BaseTest {

	public void testRead() {
		Customer c = (Customer) customerDB.read(1);
		assertTrue(c != null);
		assertTrue(c.getId() == 1);
	}
	
	public void testCreateDelete() {
		List<Customer> allCustomerStart = customerDB.readAll();

		customerDB.create("Test Customer", "555-1212");
		customerDB.create("Test Customer2", "555-3434");

		// Should have 2 more
		assertEquals(allCustomerStart.size() + 2, customerDB.readAll().size());
		
		Customer s1 = (Customer) customerDB.read("Test Customer");
		assertEquals("Test Customer", s1.getName());
		assertEquals("555-1212", s1.getPhone());
		Customer s2 = (Customer) customerDB.read("Test Customer2");
		assertEquals("Test Customer2", s2.getName());
		assertEquals("555-3434", s2.getPhone());
		customerDB.delete(s1);
		customerDB.delete(s2);
		
		// Two more should be gone
		assertEquals(allCustomerStart.size(), customerDB.readAll().size());		
	}

}
