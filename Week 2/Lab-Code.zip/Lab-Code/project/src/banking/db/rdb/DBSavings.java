package banking.db.rdb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import banking.db.SavingsAccessor;
import banking.entity.core.Savings;

public class DBSavings extends BaseDB implements SavingsAccessor {

    protected static String createAccountSQL= 
            "INSERT INTO Account (accountid, customerid, name, balance) VALUES (?, ?, ?, ?)";

    protected static String createSavingsSQL= new String(
            "INSERT INTO Savings (accountid, numwithdraws) VALUES (?, ?)");


    /** Insert a row into Account and Savings tables for the new object.
        We cheat and use the newId <b>always</b>.  In reality we
        should have the DB autoincrement the accountID field.  Args must
        be {customerID, name, balance}
     */
    public Savings create(int customerId, String name, int balance) {

        int accountId = newId++;

        try {
            Connection conn = mgr.allocate();
            PreparedStatement stmt = null;
            try {
                stmt = conn.prepareStatement(createAccountSQL);
                stmt.setInt(1, accountId);
                stmt.setInt(2, customerId);
                stmt.setString(3, name);
                stmt.setInt(4, balance);
                stmt.executeUpdate();

                stmt = conn.prepareStatement(createSavingsSQL);
                stmt.setInt(1, accountId);
                stmt.setInt(2, 0);			// num withdraws
                stmt.executeUpdate();

                conn.commit();

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // We saved it, now read it back in again.
        return read(accountId);
    }

    public Savings read(int id) {
        return privateRead("Account.accountid = " + id);
    }

    public Savings read(String name) {
        return privateRead("Account.name = '" + name + "'");
    }

    public List<Savings> readAll() {
        List<Savings> result = new ArrayList<Savings>();

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                stmt = conn.createStatement();
if (debug) System.out.println("SQL:" + readSQL);
                rs = stmt.executeQuery(readSQL);
                while (rs.next()) {
                    result.add(new Savings(rs.getInt(1),
                                            rs.getInt(2),
                                            rs.getString(3),
                                            rs.getInt(4)));
                }

            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;

    }

    protected static String readSQL=
            "SELECT Account.accountid, Account.customerid, Account.name," +
                    " Account.balance, Savings.numWithdraws" +
            " FROM Account, Savings" +
            " WHERE Account.accountid = Savings.accountid";

    protected Savings privateRead(String criteria) {

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                String sql = readSQL + " and " + criteria;
if (debug) System.out.println("SQL:" + sql);

                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
                if (rs.next())
                    return new Savings(rs.getInt(1),
                                       rs.getInt(2),
                                       rs.getString(3),
                                       rs.getInt(4));
                else
                    return null;
            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected static MessageFormat updateSQL= new MessageFormat(
            "UPDATE Account SET name=''{1}'', balance={2,number,##########} WHERE accountID={0}");

    public void update(Savings save) {

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();
                Object[] args = {new Integer(save.getId()),
                                 save.getName(),
                                 new Integer(save.getBalance())};

if (debug) System.out.println("SQL:" + updateSQL.format(args));
                stmt.executeUpdate(updateSQL.format(args));
                conn.commit();
            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected static String deleteAccountSQL =
                            "DELETE FROM Account WHERE accountID=";
    protected static String deleteSavingsSQL =
                            "DELETE FROM Savings WHERE accountID=";

    public void delete(Savings account) {

        int id = account.getId();
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

if (debug) System.out.println("SQL:" + deleteAccountSQL + id);
                stmt.executeUpdate(deleteAccountSQL + id);

if (debug) System.out.println("SQL:" + deleteSavingsSQL + id);
                stmt.executeUpdate(deleteSavingsSQL + id);

                conn.commit();

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            System.out.println("Could not delete Account " + id + ":" +
                e.getMessage());
        }
    }
}
