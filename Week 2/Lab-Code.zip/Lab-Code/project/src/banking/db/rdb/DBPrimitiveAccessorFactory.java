package banking.db.rdb;

import banking.db.CheckingAccessor;
import banking.db.CustomerAccessor;
import banking.db.EntityAccessorFactory;
import banking.db.SavingsAccessor;

public class DBPrimitiveAccessorFactory implements EntityAccessorFactory {

	public CheckingAccessor getCheckingAccessor() {
		return new DBChecking();
	}

	public CustomerAccessor getCustomerAccessor() {
		return new DBCustomer();
	}

	public SavingsAccessor getSavingsAccessor() {
		return new DBSavings();
	}

}
