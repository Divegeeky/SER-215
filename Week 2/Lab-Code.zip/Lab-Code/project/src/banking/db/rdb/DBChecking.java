package banking.db.rdb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import banking.db.CheckingAccessor;
import banking.entity.core.Checking;

public class DBChecking extends BaseDB implements CheckingAccessor {

    /* Account table is accountID, customerID, name, balance */
    protected static String createAccountSQL= 
            "INSERT INTO Account (accountid, customerid, name, balance) VALUES (?, ?, ?, ?)";

    /* Checking table is accountID, numwithdraws*/
    protected static String createCheckingSQL= new String(
            "INSERT INTO Checking (accountid, numwithdraws) VALUES (?, ?)");


    /** Insert a row into Account and Checking tables for the new object.
        We cheat and use the newId <b>always</b>.  In reality we
        should have the DB autoincrement the accountID field.  Args must
        be {customerID, name, balance}
     */
    public Checking create(int customerId, String name, int balance) {

        int accountId = newId++;

        try {
            Connection conn = mgr.allocate();
            PreparedStatement stmt = null;
            try {
                stmt = conn.prepareStatement(createAccountSQL);
                stmt.setInt(1, accountId);
                stmt.setInt(2, customerId);
                stmt.setString(3, name);
                stmt.setInt(4, balance);
                stmt.executeUpdate();

                stmt = conn.prepareStatement(createCheckingSQL);
                stmt.setInt(1, accountId);
                stmt.setInt(2, 0);			// num withdraws
                stmt.executeUpdate();

                conn.commit();

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // We saved it, now read it back in again.
        return read(accountId);
    }

    public Checking read(int id) {
        return privateRead("Account.accountid = " + id);
    }

    public Checking read(String name) {
        return privateRead("Account.name = '" + name + "'");
    }

    public List<Checking> readAll() {
        List<Checking> result = new ArrayList<Checking>();
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                stmt = conn.createStatement();
if (debug) System.out.println("SQL:" + readSQL);
                rs = stmt.executeQuery(readSQL);
                while (rs.next()) {
                    result.add(new Checking(rs.getInt(1),
                                            rs.getInt(2),
                                            rs.getString(3),
                                            rs.getInt(4)));
                }

            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;

    }

    protected static String readSQL=
            "SELECT Account.accountid, Account.customerid, Account.name," +
                    " Account.balance, Checking.numWithdraws" +
            " FROM Account, Checking" +
            " WHERE Account.accountid = Checking.accountid";

    protected Checking privateRead(String criteria) {

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                String sql = readSQL + " and " + criteria;
if (debug) System.out.println("SQL:" + sql);

                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
                if (rs.next())
                    return new Checking(rs.getInt(1),
                                       rs.getInt(2),
                                       rs.getString(3),
                                       rs.getInt(4));
                else
                    return null;
            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected static MessageFormat updateSQL= new MessageFormat(
            "UPDATE Account SET name=''{1}'', balance={2,number,##########} WHERE accountID={0}");

    public void update(Checking check) {

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();
                Object[] args = {new Integer(check.getId()),
                				 check.getName(),
                                 new Integer(check.getBalance())};

if (debug) System.out.println("SQL:" + updateSQL.format(args));
                stmt.executeUpdate(updateSQL.format(args));
                conn.commit();
            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected static String deleteAccountSQL =
                            "DELETE FROM Account WHERE accountID=";
    protected static String deleteCheckingSQL =
                            "DELETE FROM Checking WHERE accountID=";

    public void delete(Checking account) {

        int id = ((Checking) account).getId();
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

if (debug) System.out.println("SQL:" + deleteAccountSQL + id);
                stmt.executeUpdate(deleteAccountSQL + id);

if (debug) System.out.println("SQL:" + deleteCheckingSQL + id);
                stmt.executeUpdate(deleteCheckingSQL + id);

                conn.commit();

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            System.out.println("Could not delete Account " + id + ":" +
                e.getMessage());
        }
    }
}
