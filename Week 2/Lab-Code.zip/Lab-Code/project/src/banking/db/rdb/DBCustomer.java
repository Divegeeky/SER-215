package banking.db.rdb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import banking.db.CustomerAccessor;
import banking.entity.core.Customer;

public class DBCustomer extends BaseDB implements CustomerAccessor {


    /* Customer table */
    protected static String createCustomerSQL =
            "INSERT INTO Customer (customerid, name, phone)" +
            " VALUES ( ?, ?, ? )";


    /** Insert a row into Customer table for the new object.
		  Args must be {customerID, name, balance}
     */
    public Customer create(String name, String phone) {

       int customerId = newId++;

        try {
            Connection conn = mgr.allocate();
            PreparedStatement stmt = null;
            try {
                stmt = conn.prepareStatement(createCustomerSQL);
                stmt.setInt(1, customerId);
                stmt.setString(2, name);
                stmt.setString(3, phone);

                stmt.executeUpdate();

                conn.commit();

             // the Thread.sleep was added for assignment 2
//             	try {
//                        Thread.sleep(3000);
//                    } catch (Exception e){}

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return read(customerId);
    }

    public Customer read(int id) {
        return privateRead("Customer.customerid = " + id);
    }

    public Customer read(String name) {
        return privateRead("Customer.name = '" + name + "'");
    }

    public List<Customer> readAll() {
        List<Customer> result = new ArrayList<Customer>();

        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                stmt = conn.createStatement();
if (debug) System.out.println("SQL:" + readSQL);
                rs = stmt.executeQuery(readSQL);
                while (rs.next()) {
                    result.add(new Customer(rs.getInt(1),
                                       		rs.getString(2),
                                            rs.getString(3)));
                }

            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;

    }

    protected static String readSQL=
            "SELECT Customer.customerid , Customer.name, Customer.phone" +
            " FROM Customer";

    protected Customer privateRead(String criteria) {
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            ResultSet rs = null;
            try {
                String sql = readSQL + " WHERE " + criteria;

if (debug) System.out.println("SQL:" + sql);

                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
                if (rs.next())
           		  return new Customer(rs.getInt(1),
                                       		rs.getString(2),
                                            rs.getString(3));
                else {
                    return null;
                }
            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected static MessageFormat updateSQL= new MessageFormat(
            "UPDATE Customer SET name=''{1}'', phone=''{2}'' WHERE customerid={0}");

    public void update(Customer account) {

        Customer save = (Customer) account;
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();
                Object[] args = {new Integer(save.getId()),
                                 save.getName(),
                                 save.getPhone()};

if (debug) System.out.println("SQL:" + updateSQL.format(args));
                stmt.executeUpdate(updateSQL.format(args));
                conn.commit();
            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Could not update customer " + ":" +
                e.getMessage());
        }
    }

;
    protected static String deleteCustomerSQL =
                            "DELETE FROM Customer WHERE customerId=";

    public void delete(Customer account) {

        int id = ((Customer) account).getId();
        try {
            Connection conn = mgr.allocate();
            Statement stmt = null;
            try {
                stmt = conn.createStatement();

if (debug) System.out.println("SQL:" + deleteCustomerSQL + id);
                stmt.executeUpdate(deleteCustomerSQL + id);

                conn.commit();

            } finally {
                if (stmt != null) stmt.close();
                mgr.release(conn);
            }
        } catch (SQLException e) {
            System.out.println("Could not delete Customer " + id + ":" +
                e.getMessage());
        }
    }
}
