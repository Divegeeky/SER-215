package banking.db.rdb;

public abstract class BaseDB  {

    public static int newId = 123; 	// hardcoded ID - boo.
                            		// Should have DB autogenerate.


    public static ConnectionMgr mgr = ConnectionMgr.getMe();
    public static boolean debug =
             "true".equalsIgnoreCase(System.getProperty("Debug"));

}
