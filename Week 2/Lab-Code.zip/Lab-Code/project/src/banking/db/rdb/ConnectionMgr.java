package banking.db.rdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionMgr implements Cloneable {
    
    

    protected Object clone() throws CloneNotSupportedException {
        // TODO Auto-generated method stub
        return null;
    }
    protected static ConnectionMgr singleton = null;

    protected String        dburl = null;
    protected Connection    connectionPool[] = null;
    protected int           numConnections;
    protected int           pos;
    protected boolean       debug;

    public synchronized static ConnectionMgr getMe() {
        if (singleton == null) {
            singleton = new ConnectionMgr();
        }
        return singleton;
    }

    private ConnectionMgr() {
        dburl = System.getProperty("db.url");
        String dbdriver = System.getProperty("db.driver");
        String numConnS = System.getProperty("db.connections");
        System.out.println("Connecting to database: " + dburl);
        System.out.println("Database driver is: " + dbdriver);
        System.out.println("Connection pool size is: " + numConnS);

        if (dburl == null || "".equals(dburl)) {
            throw new RuntimeException("*** System property db.url not set");
        }

        if (dbdriver == null || "".equals(dbdriver)) {
            throw new RuntimeException("*** System property db.driver not set");
        }

        try {
            numConnections = Integer.parseInt(numConnS);
        } catch (Exception e) {
            throw new RuntimeException("*** System property db.connections not set");
        }

        debug = "true".equalsIgnoreCase(System.getProperty("Debug"));

        try {
            Class.forName(dbdriver); 
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println(System.getProperties());
        try {
            pos = numConnections;
            connectionPool = new Connection[numConnections];
            for (int i=0; i < numConnections; i++) {
                connectionPool[i] = DriverManager.getConnection(dburl);
                connectionPool[i].setAutoCommit(false);
            }
        } catch (SQLException e) {
            System.out.println("*** ConnectionMgr could not allocate connections");
            e.printStackTrace();
        }
    }


    public synchronized Connection allocate() throws SQLException {
        while (pos <= 0) {
            try {
                wait();
            } catch (InterruptedException e) {e.printStackTrace();}
        }

        pos--;

        return connectionPool[pos];
    }

    public synchronized void release(Connection conn) throws SQLException {
        // In case client left connection in middle of transaction
        conn.rollback();

        connectionPool[pos] = conn;
        pos++;
        notify();
    }
}
