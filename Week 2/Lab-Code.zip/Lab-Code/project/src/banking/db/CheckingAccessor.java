package banking.db;

import java.util.List;

import banking.entity.core.Checking;

public interface CheckingAccessor {
    public Checking create(int customerId, String name, int balance);
    public Checking read(int id);
    public Checking read(String name);
    public List<Checking> readAll();
    public void update(Checking obj);
    public void delete(Checking obj);
}
