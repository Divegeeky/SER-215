package banking.db.stub;


public abstract class BaseStub {

    static int newId = 123; 	// hardcoded ID - boo.
                            	// Should have DB autogenerate.
    
}
