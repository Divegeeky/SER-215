package banking.db.stub;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import banking.db.SavingsAccessor;
import banking.entity.core.Savings;

public class StubSavings extends BaseStub implements SavingsAccessor {
	
    Map<Integer, Savings> items = new HashMap<Integer, Savings>(); 
	
	public StubSavings() {
		Savings c;
		c = new Savings(1, 10, "Sav1", 2000); items.put(new Integer(c.getId()), c);
		c = new Savings(3, 11, "Sav2", 4000); items.put(new Integer(c.getId()), c);

	}
	
    public Savings create(int custId, String name, int balance) {
    	
        int id = newId++;
        Savings c = new Savings(id, custId, name, balance);
        
        items.put(new Integer(id), c);
        
        return c;
    }

    public Savings read(int id) {
    	Savings c = (Savings) items.get(new Integer(id));
    	
    	return c;
    }

    public Savings read(String name) {
    	for (Iterator<Savings> it = items.values().iterator(); it.hasNext();) {
			Savings c = it.next();
			if (name.equals(c.getName()))
				return c;
		}
    	return null;
    }

    public List<Savings> readAll() {
    	return new ArrayList<Savings>(items.values());
    }

 
    public void update(Savings account) {

        Savings save = (Savings) account;
        items.put(new Integer(save.getId()), save);
    }
    
    public void delete(Savings account) {
        Savings save = (Savings) account;
    	items.remove(new Integer(save.getId()));
    }
}