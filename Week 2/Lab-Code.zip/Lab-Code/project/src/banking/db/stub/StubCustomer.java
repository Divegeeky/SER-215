package banking.db.stub;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import banking.db.CustomerAccessor;
import banking.entity.core.Customer;

public class StubCustomer extends BaseStub implements CustomerAccessor {
	
    Map<Integer, Customer> items = new HashMap<Integer, Customer>();
	
	public StubCustomer() {
		Customer c;
		
		c = new Customer(1, "Cust1", "123-4567"); items.put(new Integer(c.getId()), c);
		c = new Customer(2, "Cust2", "987-6543"); items.put(new Integer(c.getId()), c);
	}
	
    public Customer create(String name, String phone) {
    	
        int id = newId++;
        Customer c = new Customer(id, name, phone);
        items.put(new Integer(id), c);
        
        return c;
    }

    public Customer read(int id) {
    	Customer c = (Customer) items.get(new Integer(id));
    	
    	return c;
    }

    public Customer read(String name) {
    	for (Iterator<Customer> it = items.values().iterator(); it.hasNext();) {
			Customer c = it.next();
			if (name.equals(c.getName()))
				return c;
		}
    	return null;
    }

    public List<Customer> readAll() {
    	return new ArrayList<Customer>(items.values());
    }

 
    public void update(Customer account) {

        Customer check = (Customer) account;
        items.put(new Integer(check.getId()), check);
    }
    
    public void delete(Customer account) {
        Customer check = (Customer) account;
    	items.remove(new Integer(check.getId()));
    }
}
