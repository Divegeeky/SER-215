package banking.db.stub;

import banking.db.CheckingAccessor;
import banking.db.CustomerAccessor;
import banking.db.EntityAccessorFactory;
import banking.db.SavingsAccessor;

public class StubPrimitiveAccessorFactory implements EntityAccessorFactory {

	public CheckingAccessor getCheckingAccessor() {
		return new StubChecking();
	}

	public CustomerAccessor getCustomerAccessor() {
		return new StubCustomer();
	}

	public SavingsAccessor getSavingsAccessor() {
		return new StubSavings();
	}

}
