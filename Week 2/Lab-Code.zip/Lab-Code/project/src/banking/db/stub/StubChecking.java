package banking.db.stub;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import banking.db.CheckingAccessor;
import banking.entity.core.Checking;

public class StubChecking extends BaseStub implements CheckingAccessor {
	
    Map<Integer, Checking> items = new HashMap<Integer, Checking>(); 
	
	public StubChecking() {
		Checking c;
		c = new Checking(2, 10, "Chk1", 2000); items.put(new Integer(c.getId()), c);
		c = new Checking(4, 11, "Chk2", 4000); items.put(new Integer(c.getId()), c);
		c = new Checking(5, 11, "Chk3", 5000); items.put(new Integer(c.getId()), c);
	}
	
    public Checking create(int custId, String name, int balance) {
    	
        int id = newId++;
        Checking c = new Checking(id, custId, name, balance);
        
        items.put(new Integer(id), c);
        
        return c;
    }

    public Checking read(int id) {
    	Checking c = (Checking) items.get(new Integer(id));
    	
    	return c;
    }

    public Checking read(String name) {
    	for (Iterator<Checking> it = items.values().iterator(); it.hasNext();) {
			Checking c = it.next();
			if (name.equals(c.getName()))
				return c;
		}
    	return null;
    }

    public List<Checking> readAll() {
    	return new ArrayList<Checking>(items.values());
    }

 
    public void update(Checking account) {

        Checking check = (Checking) account;
        items.put(new Integer(check.getId()), check);
    }
    
    public void delete(Checking account) {
        Checking check = (Checking) account;
    	items.remove(new Integer(check.getId()));
    }
}
