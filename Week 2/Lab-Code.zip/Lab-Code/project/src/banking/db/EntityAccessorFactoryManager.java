package banking.db;

import banking.db.rdb.DBPrimitiveAccessorFactory;
import banking.db.stub.StubPrimitiveAccessorFactory;

public class EntityAccessorFactoryManager {

    private static EntityAccessorFactoryManager singleton;

    public static EntityAccessorFactoryManager getMe() {
        if (singleton == null)
            singleton = new EntityAccessorFactoryManager();
        return singleton;
    }
    
    
    private EntityAccessorFactory dbAccessor;
    private EntityAccessorFactory stubAccessor;

    private EntityAccessorFactoryManager() {
        dbAccessor = new DBPrimitiveAccessorFactory();
        stubAccessor = new StubPrimitiveAccessorFactory();
    }

    public EntityAccessorFactory getPrimitiveAccessorFactory(String name) {
        if ("DB".equalsIgnoreCase(name))
            return dbAccessor;
        else if ("Stub".equalsIgnoreCase(name))
        	return stubAccessor;
        else
            throw new IllegalArgumentException("Bad Accessor name: " + name);
    }
}
