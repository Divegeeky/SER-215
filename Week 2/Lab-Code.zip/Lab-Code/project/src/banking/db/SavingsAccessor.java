package banking.db;

import java.util.List;

import banking.entity.core.Savings;

public interface SavingsAccessor {
    public Savings create(int customerId, String name, int balance);
    public Savings read(int id);
    public Savings read(String name);
    public List<Savings> readAll();
    public void update(Savings obj);
    public void delete(Savings obj);
}
