package banking.entity.core;
import banking.entity.InterestBearing;
public class Savings extends Account implements InterestBearing {
    private int numWithdraws = 0;

    public Savings(String name) {
        this(-1, name, 0);
    }

    public Savings(String name, int balance) {
        this(-1, name, balance);
    }

    public Savings(int id, String name, int balance) {
        super(id, name, balance);
    }

    public Savings(int id, int custId, String name, int balance) {
        super(id, custId, name, balance);
    }


    public void display() {
        System.out.print("Savings ");
        super.display();
    }

    /** Each deposit() on a Savings object is charged 10 dollars
     */
    public void deposit(int amount) {
        balance = balance + amount - 10;
    }

    public void withdraw(int amount) {
        balance = balance - amount;
        numWithdraws++;
        if (numWithdraws > 3)
            balance = balance - 1;
    }

    public void accrueInterest() {
        balance = (int) (balance * 1.001F);
    }

    public String toString() {
        return "Sav:" + getId() + ":" + getName() + ":" + getBalance();
    }
}
