package banking.entity.core;

public class Checking extends Account {
	
    private int numWithdraws = 0;
    
	public Checking(String name) {
        this(-1, name, 0);
    }

    public Checking(String name, int balance) {
        this(-1, name, balance);
    }

    public Checking(int id, String name, int balance) {
        super(id, name, balance);
    }

    public Checking(int id, int custId, String name, int balance) {
        super(id, custId, name, balance);
    }


    public void display() {
        System.out.print("Checking ");
        super.display();
    }

    public void deposit(int amount) {
        balance = balance + amount;
    }

    public void withdraw(int amount) {
        balance = balance - amount;
        numWithdraws++;
        if (numWithdraws > 10)
            balance = balance - 2;
    }

    public String toString() {
        return "Chk:" + getId() + ":" + getName() + ":" + getBalance();
    }
}
