package banking.entity.core;

import banking.entity.Asset;
public abstract class Account implements Asset {

    protected int id;
    protected String name;
    protected int balance;
    protected int customerId;
	public Account(int id, int custId, String n, int b) {
        this.id = id;
        name = n;
        balance = b;
        customerId = custId;
    }

    public Account(int id, String n, int b) {
        this(id, -1, n, b);
    }

    public void display() {
        System.out.println("Account " + name + " has $" + balance);
    }

    public int getId() {
        return id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String n) {
        name = n;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance (int b) {
        balance = b;
    }

    public abstract void deposit(int amount);
    public abstract void withdraw(int amount);

}
