package banking.entity;

public interface Asset extends java.io.Serializable {
    public void   display();
    public String getName();
}
