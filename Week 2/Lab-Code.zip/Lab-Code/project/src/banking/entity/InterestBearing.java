package banking.entity;

public interface InterestBearing {
    public void accrueInterest();
}
