package banking.server;

import banking.entity.core.*;

import java.io.*;

public class BankServerTest {

	public static void main(String args[]) throws IOException {

        BankServer server = new BankServer();
        
        System.out.println("******* Initial State ******");
        System.out.println(server.getAllAccounts());
        System.out.println("****************************");

        Customer cust = server.newCustomer("test", "1234567");
        System.out.println("new customer:" + cust);
        cust = server.getCustomer("test");
        System.out.println("get customer:" + cust);
        System.out.println("should have no accounts :" + server.getAccounts(cust));

        Account c = server.newAccount("Checking", "testchk", 0, cust);
        Account s = server.newAccount("Savings", "testsav", 100, cust);
        System.out.println("should have 2 accounts :" + server.getAccounts(cust));

        c = server.getAccount("testchk");
        s = server.getAccount("testsav");
        System.out.println("get account :" + c + " and " + s);

        c.deposit(222);
        server.updateAccount(c);

        s.deposit(1000);
        server.updateAccount(s);

        server.displayAllAccounts();
        server.deleteAccount(c);
        server.deleteAccount(s);
        server.deleteCustomer(cust);

        System.out.println("******* Ending State *******");
        System.out.println(server.getAllAccounts());
        System.out.println("****************************");

    }
}
