package banking.server;

import banking.db.CheckingAccessor;
import banking.db.CustomerAccessor;
import banking.db.EntityAccessorFactory;
import banking.db.EntityAccessorFactoryManager;
import banking.db.SavingsAccessor;
import banking.entity.core.*;
import java.util.*;

public class BankServer {

	SavingsAccessor savingsDB;
	CheckingAccessor checkingDB;
	CustomerAccessor customerDB;

    public BankServer() {
		String factoryName = System.getProperty("banking.db.test.factoryname");
		if (factoryName == null)
			factoryName = "Stub";
		
		EntityAccessorFactoryManager mgr = EntityAccessorFactoryManager.getMe();
		EntityAccessorFactory factory = mgr.getPrimitiveAccessorFactory(factoryName);
		savingsDB = factory.getSavingsAccessor();
		checkingDB = factory.getCheckingAccessor();
		customerDB = factory.getCustomerAccessor();
    }

    public  Customer newCustomer(String name, String phone) {
        return (Customer) customerDB.create(name, phone);
    }

    public List getAllAccounts() {
        List result = savingsDB.readAll();
        List ckList = checkingDB.readAll();
        result.addAll(ckList);

        return result;
    }

    public List<Account> getAccounts(Customer cust) {
        List<Account> result = new ArrayList<Account>();

        List<Account> all = getAllAccounts();
        for (int i=0; i < all.size(); i++) {
            Account acc = (Account) all.get(i);
            if (acc.getCustomerId() == cust.getId())
                result.add(acc);
        }

        return result;
    }


    public  void updateAccount(Account acc) {
        if (acc instanceof Savings)
            savingsDB.update( (Savings) acc);
        else if (acc instanceof Checking)
            checkingDB.update( (Checking) acc);
        else
            throw new IllegalArgumentException(
                "Unkown Account type:" + acc.getClass());
    }

    public  void updateCustomer(Customer cust) {
        if (cust instanceof Customer)
            customerDB.update(cust);
        else
            throw new IllegalArgumentException(
                "Unkown Account type:" + cust.getClass());
    }




    public Customer getCustomer(String name) {
        return (Customer) customerDB.read(name);
    }

    public void   deleteCustomer(Customer a) {
        customerDB.delete(a);
    }


    public  Account  newAccount(String type, String name, int balance, Customer cust) {
         if(type.equals("Savings")) {
            return (Account) savingsDB.create(cust.getId(), name, balance);
        } else { //the account type is checking***
            return (Account) checkingDB.create(cust.getId(), name, balance);
        }
   }

    public Account getAccount(String name) {
        if(checkingDB.read(name)!= null) {
            return (Account) checkingDB.read(name);
        } else {
            return (Account) savingsDB.read(name);
        }
    }

    public  void deleteAccount(Account a) {
        int id = a.getId();
        if( checkingDB.read(id)!= null) {
            checkingDB.delete( (Checking) a);
        } else { //account is a saving account
            savingsDB.delete( (Savings) a);
        }
    }


    public void displayAllAccounts() {

        List all = savingsDB.readAll();
        all.addAll(checkingDB.readAll());
        System.out.println("All accounts:"+all);
    }

    public List<Customer> getAllCustomers() {
        List<Customer> all = customerDB.readAll();
        System.out.println("All customers:"+all);

        return all;
    }
}
