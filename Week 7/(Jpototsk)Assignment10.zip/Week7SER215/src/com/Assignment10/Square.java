package com.Assignment10;

public class Square extends GeometricObject implements Colorable {
	private double side;
	public Square(double side){
		this.side = side;
	}
	public double getArea(){
		double Area = Math.pow(side, 2);
		return Area;
	}
	public double getPerimeter(){
		double Perim = side * 4;
		return Perim;
	}
	public void howToColor(){
		System.out.println("Color all four sides.");
	}
}
