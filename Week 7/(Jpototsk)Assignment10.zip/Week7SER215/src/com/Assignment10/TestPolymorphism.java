package com.Assignment10;

public class TestPolymorphism {

	public static void main(String[] args) {
		GeometricObject[] mygeoarray = new GeometricObject[5];
		Square object1 = new Square(6);
		Square object2 = new Square(7);
		Circle object3 = new Circle(8);
		Circle object4 = new Circle(9);
		Square object5 = new Square(10);
		mygeoarray[0]=object1;
		mygeoarray[1]=object2;
		mygeoarray[2]=object3;
		mygeoarray[3]=object4;
		mygeoarray[4]=object5;
		
		for (int i=0; i< mygeoarray.length; i++){
			if (mygeoarray[i] instanceof Square){
				((Square)mygeoarray[i]).howToColor();
			}
			
			System.out.println("The object's Area at index " + i + " is: "+ mygeoarray[i].getArea());
			System.out.println("The object's Perimiter at index " + i + " is: " + mygeoarray[i].getPerimeter());
			
			
		}
		

	}

}
