package com.Assignment10;

public interface Colorable {
	void howToColor();
}
